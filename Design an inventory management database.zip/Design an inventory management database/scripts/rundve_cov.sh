#!/bin/sh


dve \
	-full64 \
	-covdir ./compile_cov/cov.vdb \
	-covdir ./sim_cov/cov.vdb