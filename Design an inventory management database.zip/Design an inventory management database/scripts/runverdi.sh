#!/bin/sh


verdi \
	-full64 \
	-ssf novas.fsdb