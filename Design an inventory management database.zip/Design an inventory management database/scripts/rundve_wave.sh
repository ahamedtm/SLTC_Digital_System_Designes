#!/bin/sh


dve \
	-full64 \
	-vpd vcdplus.vpd