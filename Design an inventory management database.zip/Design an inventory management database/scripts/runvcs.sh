#!/bin/sh
#-debug_pp \
#+vcs+fsdbon \
#-kdb \

vcs \
    -full64 \
    -debug_access+all \
    -sverilog \
    -notice \
    -lca \
    -cm_dir ./compile_cov/cov.vdb \
    -cm line+cond+fsm+tgl+branch \
    -timescale=1ns/10ps \
    +lint=TFIPC-L \
    +lint=PCWM \
    +vcs+vcdpluson \
    +vcs+lic+wait \
    -file ../sim/simfile.f \
    -l vcs.log
