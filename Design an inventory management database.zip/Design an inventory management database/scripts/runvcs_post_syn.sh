#!/bin/sh


vcs \
    -full64 \
    -debug_pp \
    -sverilog \
    -notice \
    -y $XILINX_VIVADO/data/verilog/src/unisims \
    -y $XILINX_VIVADO/data/verilog/src/unimacro \
    -y $XILINX_VIVADO/data/verilog/src/unisims_dr \
    +libext+.v \
    +incdir+$XILINX_VIVADO/data/verilog/src \
    -file ../sim/v17/simfiles_post_syn.f \
    -l vcs.log \
    -LDFLAGS '-lpcap'