#!/bin/sh


./simv \
	-cm_dir ./sim_cov/cov.vdb \
	-cm line+cond+fsm+tgl+branch