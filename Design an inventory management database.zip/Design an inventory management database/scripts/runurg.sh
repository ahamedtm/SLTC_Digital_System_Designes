#!/bin/sh


urg \
	-dir ./compile_cov/cov.vdb \
	-dir ./sim_cov/cov.vdb
	