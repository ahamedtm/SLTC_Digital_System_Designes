
#ifndef INCLUDED_DPIC_IF
#define INCLUDED_DPIC_IF

#ifdef __cplusplus
#define DPI_LINK_DECL  extern "C" 
#else
#define DPI_LINK_DECL 
#endif

#include "svdpi.h"

DPI_LINK_DECL DPI_DLLESPEC
void
svInsertCnt(
	unsigned int svVh,
	unsigned int* svError);

DPI_LINK_DECL DPI_DLLESPEC
void
svGetCnt(
	unsigned int svVh,
	unsigned int* svCnt,
	unsigned int* svError);

#endif