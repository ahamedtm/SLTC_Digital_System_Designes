#include "dpic_if.h"
#include "food_database.h"

int food_cnt [4];

food_database *fd;

DPI_LINK_DECL DPI_DLLESPEC
void
svInsertCnt(
	unsigned int svVh,
	unsigned int* svError)
{	
	fd = new food_database();
	fd->insert_cnt(svVh, food_cnt);
	*svError = 0;
}

DPI_LINK_DECL DPI_DLLESPEC
void
svGetCnt(
	unsigned int svVh,
	unsigned int* svCnt,
	unsigned int* svError)
{		
	*svCnt = food_cnt[svVh];
	*svError = 0;
}