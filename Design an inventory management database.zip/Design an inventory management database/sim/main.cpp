
#include "food_database.h"

int main () {
    int food_cnt [4] = {0, 0, 0, 0};
    int fd_ty, total_cnt = 0;

    food_database *fd;
    fd = new food_database();

    for (fd_ty = 0; fd_ty < 4; fd_ty++) {
        fd->insert_cnt(fd_ty, food_cnt);
    }
    
    for (fd_ty = 0; fd_ty < 4; fd_ty++) {
        std::cout << "food type " << fd_ty << " " << food_cnt[fd_ty] << std::endl; 
        total_cnt += food_cnt[fd_ty];
    }

    std::cout << "total food cnt " << total_cnt << std::endl;

    return 0;
}