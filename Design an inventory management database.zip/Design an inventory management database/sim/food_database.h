#ifndef HEADER_FOOD_DATABASE_H_
#define HEADER_FOOD_DATABASE_H_

#include <iostream>

class food_database {
public:
	food_database ();
	~food_database ();
	void insert_cnt (int fd_ty, int food_cnt[4]);
};

#endif