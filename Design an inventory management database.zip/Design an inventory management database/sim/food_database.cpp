#include "food_database.h"

food_database::food_database () {

}

food_database::~food_database () {
    
}

void food_database::insert_cnt (int fd_ty, int food_cnt[4]) {
    std::cout << "insert_cnt fd_ty " << fd_ty << std::endl;

    std::cout << "current count " << food_cnt[fd_ty] << std::endl;
    food_cnt[fd_ty] ++;
    std::cout << "new count " << food_cnt[fd_ty] << std::endl;
}