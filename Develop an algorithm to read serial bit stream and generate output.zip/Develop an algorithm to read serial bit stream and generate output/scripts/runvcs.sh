#!/bin/sh
#indunil_wanigasooriya
#indunil@paraqum.com

vcs \
	-full64 \
	-debug_pp \
	-sverilog \
	-notice \
	-cm_dir ./compile_cov/cov.vdb \
	-cm line+cond+fsm+tgl+branch \
	-file ../sim/simfile.f \
	-l vcs.log