#!/bin/sh
#indunil_wanigasooriya
#indunil@paraqum.com

urg \
	-dir ./compile_cov/cov.vdb \
	-dir ./sim_cov/cov.vdb
	