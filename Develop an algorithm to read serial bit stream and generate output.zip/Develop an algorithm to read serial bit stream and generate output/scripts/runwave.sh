#!/bin/sh
#indunil_wanigasooriya
#indunil@paraqum.com

dve \
	-full64 \
	-vpd vcdplus.vpd