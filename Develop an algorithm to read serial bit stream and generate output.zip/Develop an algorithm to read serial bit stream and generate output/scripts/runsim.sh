#!/bin/sh
#indunil_wanigasooriya
#indunil@paraqum.com

./simv \
	-cm_dir ./sim_cov/cov.vdb \
	-cm line+cond+fsm+tgl+branch