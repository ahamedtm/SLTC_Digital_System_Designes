#ifndef HEADER_PATTERN_READER_H_
#define HEADER_PATTERN_READER_H_

#include <iostream>
#include <fstream>
#include <string>

class pattern_reader {
public:
	int patter_match_1 [8] = {0, 1, 1, 0, 1, 0, 1, 1};
	int patter_match_2 [2] = {0, 1};

	//std::string input_stream = "01101011";
	//std::string input_stream = "0110101101101011";
	std::string input_stream = "011010110110101101101011";

	pattern_reader ();
	~pattern_reader ();
	void read_stream (int &bit_count, int bit_value[100], int &patt_1_cnt, int &patt_2_cnt);
};

#endif