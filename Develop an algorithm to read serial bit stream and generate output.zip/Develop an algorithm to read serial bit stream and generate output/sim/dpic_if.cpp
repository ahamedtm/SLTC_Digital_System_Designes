#include "dpic_if.h"
#include "pattern_reader.h"

int bit_count;
int bit_value [100];
int patt_1_cnt = 0;
int patt_2_cnt = 0;

pattern_reader *pat_read;


DPI_LINK_DECL DPI_DLLESPEC
void
svReadPattern(
	unsigned int* svBitCount,
	unsigned int* svError)
{
	pat_read = new pattern_reader();
	pat_read->read_stream(bit_count, bit_value, patt_1_cnt, patt_2_cnt);
	*svBitCount = bit_count;
	*svError = 0;
}

DPI_LINK_DECL DPI_DLLESPEC
void
svReadBitStream(
	unsigned int svCount,
	unsigned int* svBitValue,
	unsigned int* svError)
{
	*svBitValue = bit_value[svCount];
	*svError = 0;
}

DPI_LINK_DECL DPI_DLLESPEC
void
svGetResult(
	unsigned int* svPatt1Cnt,
	unsigned int* svPatt2Cnt,
	unsigned int* svError)
{
	*svPatt1Cnt = patt_1_cnt;
	*svPatt2Cnt = patt_2_cnt;
	*svError = 0;
}