
#ifndef INCLUDED_DPIC_IF
#define INCLUDED_DPIC_IF

#ifdef __cplusplus
#define DPI_LINK_DECL  extern "C" 
#else
#define DPI_LINK_DECL 
#endif

#include "svdpi.h"

DPI_LINK_DECL DPI_DLLESPEC
void
svReadPattern(
	unsigned int* svBitCount,
	unsigned int* svError);

DPI_LINK_DECL DPI_DLLESPEC
void
svReadBitStream(
	unsigned int svCount,
	unsigned int* svBitValue,
	unsigned int* svError);

DPI_LINK_DECL DPI_DLLESPEC
void
svGetResult(
	unsigned int* svPatt1Cnt,
	unsigned int* svPatt2Cnt,
	unsigned int* svError);

#endif