#include "pattern_reader.h"

pattern_reader::pattern_reader () {

}

pattern_reader::~pattern_reader () {
	
}

void pattern_reader::read_stream (int &bit_count, int bit_value[100], int &patt_1_cnt, int &patt_2_cnt) {
	bit_count = input_stream.length();
	std::cout << "no_of_bit = " << bit_count << std::endl;
	std::cout << "#################" << std::endl;

	for (int i = 0; i < input_stream.length(); i++) {
		bit_value[i] = input_stream.at(i) - 48;
		//std::cout << "bit_value [" << i << "] = " << input_stream.at(i) << std::endl;
		std::cout << "bit_value [" << i << "] = " << bit_value[i] << std::endl;
	}
	std::cout << "#################" << std::endl;

	//check patern 1 occurences
	for (int i = 0; i < ((bit_count - 8) + 1); i++) {
		for (int j = 0; j < 8; j++) {
			if (patter_match_1[j] != bit_value[i+j]) {
				break;
			}
			else if (j == 7) {
				patt_1_cnt++;
			}
		}
	}
	std::cout << "patter_1_count = " << patt_1_cnt << std::endl;
	std::cout << "#################" << std::endl;

	//check patern 2 occurences
	for (int i = 0; i < ((bit_count - 2) + 1); i++) {
		for (int j = 0; j < 2; j++) {
			if (patter_match_2[j] != bit_value[i+j]) {
				break;
			}
			else if (j == 1) {
				patt_2_cnt++;
			}
		}
	}
	std::cout << "patter_2_count = " << patt_2_cnt << std::endl;
}