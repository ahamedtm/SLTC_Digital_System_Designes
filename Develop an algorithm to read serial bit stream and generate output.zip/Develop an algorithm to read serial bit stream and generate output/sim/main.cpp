//indunil wanigasooriya
#include "pattern_reader.h"

int main () {
	int bit_count;
	int bit_value [100];
	int patt_1_cnt = 0;
	int patt_2_cnt = 0;

	pattern_reader *pat_read;

	pat_read = new pattern_reader();
	pat_read->read_stream(bit_count, bit_value, patt_1_cnt, patt_2_cnt);

	return 0;
}